Database 
Skriv dina egna reflektioner kring uppgiften i ett textdokument.
(Lätt/svårt/roligt/tråkigt osv. och varför?)



Det verkar väldigt enkelt, men när jag göra det,finns det många 
små detaljer som är lätta att göra misstag. Så det behövers mer repetition och övning.
Detta övar logiska färdigheter. Jag gör ofta misstag på vägen.
Vissa studenter har mycket bra idéer. 
Det vore bättre om de hade möjlighet att visa sina sätter efter varje uppgift.